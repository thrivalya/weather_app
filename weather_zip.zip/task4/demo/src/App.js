import "./app.css";
import { useState, useEffect } from "react";

function App() {
  const [data, setData] = useState({});
  const [getLocationClicked, setGetLocationClicked] = useState(false);


  const f = () => {
    let reqTemp = document.getElementById("reqTemp");
    reqTemp.innerHTML = data.current.temp_f;
  };
  const c = () => {
    let reqTemp = document.getElementById("reqTemp");
    reqTemp.innerHTML = data.current.temp_c;
  };

  const handleKeyPress = (event) => {
    if (event.key === 'Enter') {
      search();
    }
  };

  const fetchData = async (url) => {
    try {
      let response = await fetch(url);
      let data = await response.json();
      setData(data);
      console.log(data);

    } catch (error) {
      console.error("Error fetching data:", error);
    }
  };

  const search = async () => {
    const element = document.getElementsByClassName("search");
    if (element[0].value === "") {
      return 0;
    }

    let url = `http://api.weatherapi.com/v1/forecast.json?key=c5a7dccbb6764982bd574518240102&q=${element[0].value}&days=7&aqi=no&alerts=no`;
    fetchData(url);
  };
  const getLocation = () => {
    setGetLocationClicked(true);
    navigator.geolocation.getCurrentPosition(gotLocation, failedToGet);
  };

  const gotLocation = (position) => {
    const { latitude, longitude } = position.coords;
    const url = `http://api.weatherapi.com/v1/forecast.json?key=c5a7dccbb6764982bd574518240102&q=${latitude},${longitude}&days=7&aqi=no&alerts=no`;
    console.log(url);
    fetchData(url);

  };

  const failedToGet = () => {
    console.log("There was some issue fetching the location");
  };

  useEffect(() => {
    if (!getLocationClicked) {
      getLocation();
    }
  }, [getLocationClicked]);

  return (
<div className={
  (typeof data.current !== 'undefined' && typeof data.current.temp_c !== 'undefined')
    ? ((data.current.temp_c > 25)
      ? 'app'
      : (data.current.temp_c > 16)
        ? 'app'
        : 'app cool')
    : 'app'}>
<div className="top container">
        <div className="row">
          
          <input onKeyPress={handleKeyPress} type="text" placeholder="search city..." className="search col-10" />
          <img src="https://uxwing.com/wp-content/themes/uxwing/download/user-interface/search-icon.png" className="search" onClick={() => { search() }} style={{width:'50px',height:'50px',border:'0px'}}/>
          <img src="https://www.iconpacks.net/icons/2/free-location-icon-2952-thumb.png"  onClick={() => {getLocation();}} style={{width:'70px',height:'50px',border:'0px'}}/>
          </div>
      </div>

      {(Object.keys(data).length !== 0) ? (
        <div>
          <h1 className="h1">{data.location.name},{data.location.country}</h1>
          <p>{data.location.localtime}</p>
          <div className="container">
      <div className="row">
      <div style={{width:'70vh' ,height:'50vh'}} className="container card col-6 d-flex align-items-center justify-content-center text-center" >
      <div  className="image-container">
          <img src={data.current.condition.icon}/>
          <p>Temperature</p>
            </div>  
        <div className="row">
         
            <br/>    
          <div className="col-2 ">
          <h1 className="temp d-flex align-items-center justify-content-center" id="reqTemp">{data.current.temp_c}</h1>
          </div>
          <div className="col-2 text-center" style={{fontSize:'20px'}}>
            <p onClick={f}>°F</p>
            <hr />
            <p onClick={c}>°C</p>
          </div>

          <div className="col-1" style={{ borderLeft: '1px solid #000000', height: '150px'}}></div>

          <div className="col-5 d-flex flex-column align-items-center">
           <div className="image-container" >
            <img src="https://www.freeiconspng.com/uploads/sun-icon-15.png" style={{ width: '50px', height: '50px' }}/>
            <p>Real feel: {data.current.pressure_in}°</p>
            </div>
            <div className="image-container">
              <img src="https://cdn-icons-png.flaticon.com/512/1582/1582886.png" style={{ width: '50px', height: '50px' }} />
            <p>Humidity: {data.current.humidity}%</p>
            </div>
            <div className="image-container">
              <img src="https://creazilla-store.fra1.digitaloceanspaces.com/icons/3216052/wind-icon-md.png" style={{ width: '45px', height: '50px' }}/>
            <p>Wind: {data.current.wind_kph}km/h</p>
            </div>
          </div>
          
         
        </div>
        
        <div className="image-container" style={{margin:'10px'}}>
            <div >
            <p>Sun Rise </p>
            <p>{data.forecast.forecastday[0].astro.sunrise}</p>
          </div>
          <div style={{ borderLeft: '1px solid rgba(37, 37, 39, 0.5)', height: '70px', margin: '5px' }}></div>

          <div>
            <p>Sun Set  </p>
            <p>{data.forecast.forecastday[0].astro.sunset}</p>
          </div>
          <div style={{ borderLeft: '1px solid rgba(37, 37, 39, 0.5)', height: '70px', margin: '5px' }}></div>

          <div>
            <p>Moon Rise  </p>
            <p>{data.forecast.forecastday[0].astro.moonrise}</p>
          </div>
          <div style={{ borderLeft: '1px solid rgba(37, 37, 39, 0.5)', height: '70px', margin: '5px' }}></div>

          <div>
            <p>Moon Set  </p>
            <p>{data.forecast.forecastday[0].astro.moonset}</p>
          </div>

          

          </div>
      </div>
    <div className="col-4" >
    <div>
    {(() => {
  const sequence = [];

  for (let i = 0; i <= 23; i += 6) {
    sequence.push(
      <div className="card" key={i}>
        <div className="image-container">
          <img src={data.forecast.forecastday[0].hour[i].condition.icon} alt={`Weather icon for ${i} hour`} />
          <p>{`${i}:00`}</p>
        </div>
        <h1 className="temp">{data.forecast.forecastday[0].hour[i].temp_c}°C</h1>
      </div>
    );
  }

  return sequence;
})()}
</div>



          
    
    </div>

    </div>
    </div>

    <div className="card" style={{width:'auto',height:'full'}}>
      <div className="container">
      <div className="row">
  {(() => {
    const elements = [];

    for (let i = 1; i <= 6; i++) {
      elements.push(
        <div className="col-2" key={i}>
          <p>{data.forecast.forecastday[i].date}</p>
          <h1 className="temp">{parseInt(data.forecast.forecastday[i].day.avgtemp_c)}°C</h1>
        </div>
      );
    }

    return elements;
  })()}
</div>
  </div>

      </div>
    </div>
      ) : ('')}
    </div>
  );
}

export default App;
